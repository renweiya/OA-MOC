clear;
clc
disp('hello')
%%
% fn_handle = @(x) limitcycle_DS(x); %defining the function handle
% x0 = [zeros(1,5);linspace(5,3,5)]; %set of initial points
% x0=[1;0];

%% ������
% fn_handle = @(x) globally_stable_DS(x); %defining the function handle
% % % % % fn_handle = @(x) [-x(1,:);zeros(1,size(x,2))];
% x0 = [-15*ones(1,8);linspace(-3,3,8)]; %set of initial points
% % % % % x0 = [-15;0]; %set of initial points
% options.model=3;
% clear obs;
% obs{1}.a  = [3;3];
% obs{1}.p  = [2;2];%[2;2];
% obs{1}.x0 = [-9;0];%[-9;0];
% obs{1}.sf = [1.2;1.2];
% obs{1}.th_r = [0 0]*pi/180;
% obs{1}.partition = [-pi pi];
%% Բ�ν���
%%
fn_handle = @(x) globally_stable_DS(x); %defining the function handle
% fn_handle = @(x) [-x(1,:);zeros(1,size(x,2))];
x0 = [-26*ones(1,15);linspace(-5,5,15)]; %set of initial points
x0 = [-26.448285*ones(1,15);linspace(-5,5,15)]; %set of initial points%min distance for [-9,-3][-9,-1][-9,1][-9,3];angle_temp=index*angle_max_(n)/2;;angle_temp*(1-w(n)/abs(Gamma(n)^(1/2)));
x0 = [-27*ones(1,9);linspace(-7,7,9)]; %set of initial points

temp_start=[-30 -28 -28 -28 -25 -25 -25 -22 -22 -20  -20 -18 -17 -15   -13]
temp_end=  [0    0   1   -1  0   1  -1   1   -1   1   -1   1  -1  1     1]
x0 = [temp_start;temp_end]; %set of initial points


% (1-((-26.448285+9)^2+1)/3.6^2)*pi/2

% x0 = [-26.448285;0]; %set of initial points
% % A set of parameters that should be defined for the simulation
options.model=3;
clear obs;
obs{1}.a  = [3;3];
obs{1}.p  = [1;1];
obs{1}.x0 = [-9;3];
obs{1}.sf = [1.2;1.2];
obs{1}.th_r = [0 0]*pi/180;
obs{1}.partition = [-pi pi];
% 
obs{2}.a  = [3;3];
obs{2}.p  = [1;1];
obs{2}.x0 = [-9;1];
obs{2}.sf = [1.2;1.2];
obs{2}.th_r = [0 0]*pi/180;
obs{2}.partition = [-pi pi];
% % 
obs{3}.a  = [3;3];
obs{3}.p  = [1;1];
obs{3}.x0 = [-9;-1];
obs{3}.sf = [1.2;1.2];
obs{3}.th_r = [0 0]*pi/180;
obs{3}.partition = [-pi pi];
% % % 
obs{4}.a  = [3;3];
obs{4}.p  = [1;1];
obs{4}.x0 = [-9;-3];
obs{4}.sf = [1.2;1.2];
obs{4}.th_r = [0 0]*pi/180;
obs{4}.partition = [-pi pi];

% obs{5}.a  = [6;6];
% obs{5}.p  = [1;1];
% obs{5}.x0 = [-9;0];
% obs{5}.sf = [1.2;1.2];
% obs{5}.th_r = [0 0]*pi/180;
% obs{5}.partition = [-pi pi];
%%  multi-obstacles

x0 = [-20*ones(1,10);linspace(-10,10,10)]; %set of initial points
options.model=3;
clear obs;
obs{1}.a  = [3;3];
obs{1}.p  = [1;1];
obs{1}.x0 = [-5;0];
obs{1}.sf = [1.2;1.2];
obs{1}.th_r = [0 0]*pi/180;
obs{1}.partition = [-pi pi];
% % % 
obs{2}.a  = [3;3];
obs{2}.p  = [1;1];
obs{2}.x0 = [-12;3];
obs{2}.sf = [1.2;1.2];
obs{2}.th_r = [0 0]*pi/180;
obs{2}.partition = [-pi pi];

obs{3}.a  = [3;3];
obs{3}.p  = [1;1];
obs{3}.x0 = [-15;-5];
obs{3}.sf = [1.2;1.2];
obs{3}.th_r = [0 0]*pi/180;
obs{3}.partition = [-pi pi];


%% Horizontal Line
fn_handle = @(x) [-x(1,:);zeros(1,size(x,2))];
x0 = [-18*ones(1,8);linspace(-10,10,8)]; %set of initial points
options.model=3;
clear obs;
obs{1}.a  = [3;3];
obs{1}.p  = [1;1];
obs{1}.x0 = [-9;0];
obs{1}.sf = [1.2;1.2];
obs{1}.th_r = [0 0]*pi/180;
obs{1}.partition = [-pi pi];

% obs{1}.rho=1;
% %%
%% limitcycle_DS
% clc
% clear
% clear obs;
% options.model=2;
% fn_handle = @(x) limitcycle_DS(x); %defining the function handle
% x0 = [zeros(1,20);linspace(3,10,20)]; %set of initial points
% x0 = [0 2 0 -2;-1 0,1 0]; %set of initial points
% % A set of parameters that should be defined for the simulation
% opt_sim.dt = 0.01; %integration time steps
% opt_sim.i_max = 3000; %maximum number of iterations
% opt_sim.tol = 0.05; %convergence tolerance
% opt_sim.plot = true; %enabling the animation
% opt_sim.obstacle = []; %no obstacle is defined
% obs{1}.a  = [1;1];
% obs{1}.p  = [1;1];
% obs{1}.x0 = [2;3];
% obs{1}.sf = [1.2;1.2];
% obs{1}.th_r = [0 0]*pi/180;
% obs{1}.partition = [-pi pi];
% obs{2}.a  = [1;1];
% obs{2}.p  = [1;1];
% obs{2}.x0 = [0.5;5];
% obs{2}.sf = [1.2;1.2];
% obs{2}.th_r = [0 0]*pi/180;
% obs{2}.partition = [-pi pi];
% obs{3}.a  = [1;1];
% obs{3}.p  = [1;1];
% obs{3}.x0 = [1;-2];
% obs{3}.sf = [1.2;1.2];
% obs{3}.th_r = [0 0]*pi/180;
% obs{3}.partition = [-pi pi];
% opt_sim.obstacle = obs;
% fig=[];
% fig(1) = figure('name','Second demo: Streamlines of the original DS','position',[100 550 560 420]);
% opt_sim.figure = fig(1);
% Simulation(x0,[],fn_handle,opt_sim);
%%
% opt_sim.obstacle = obs;
% fig(3) = figure('name','First demo: Multiple obstacle avoidance','position',[380 50 560 420]);
% opt_sim.figure = fig(3);
% Simulation(x0,[],fn_handle,opt_sim,options);
