
clear obs;
obs{1}.a  = [5;5;5];
obs{1}.p  = [1;1;1];
obs{1}.x0 = [0;0;0];
obs{1}.sf = [1;1;1];
obs{1}.th_r = [0 0 0]*pi/180;
obs{1}.partition = [-pi pi];

n_theta = 20;
n_phi = 15;
[x_obs x_obs_sf] = obs_draw_ellipsoid(obs,[n_theta n_phi]);
close(gcf)
figure('position',[300 300 560 420])
grid on;hold on;axis equal
for n=1:length(obs)
    h = surf(reshape(x_obs(1,:,n),n_phi,n_theta), reshape(x_obs(2,:,n),n_phi,n_theta), reshape(x_obs(3,:,n),n_phi,n_theta));
    set(h,'FaceColor',[0.6 1 0.6],'linewidth',0.1)
end
view(-50,38)
axis([-6 6 -4 4 -4 4])
