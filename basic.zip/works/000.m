syms x y z nata1 nata2 nata3 E E1 u1 u2 u3 xyz r1 r2 a b c d e f theta1 theta2
E=[x y;y -x]
E_1=E^(-1)

E=[x y z;y y*z x*z;z x*z y*z]
E=[x y z;y z x*y;z x*y z]
det(E)
E_1=E^(-1)

E=[x/sqrt(x^2+y^2) y/sqrt(x^2+y^2);y/sqrt(x^2+y^2),-x/sqrt(x^2+y^2)]
E=[x y;y,-x]

Et=E'
E_1=E^(-1)

U=[u1;u2;u3];
E=[x x*y y*x;y z*y z*x;z -(x^2+z^2) -(y^2+z^2)]
E_=expand((x^2+y^2+z^2)^2)
% E=[x/sqrt(x^2+y^2+z^2) y/sqrt(x^2+y^2) x*z/sqrt(x^2*z^2+y^2*z^2+(x^2+y^2)^2);y/sqrt(x^2+y^2+z^2) -x/sqrt(x^2+y^2) y*z/sqrt(x^2*z^2+y^2*z^2+(x^2+y^2)^2);z/sqrt(x^2+y^2+z^2) 0 -(x^2+y^2)/sqrt(x^2*z^2+y^2*z^2+(x^2+y^2)^2)]
detE=simplify(det(E))
detE=expand(detE)

tmp1=detE-E_

D=[nata1 0 0;0 nata2 0;0 0 nata3];
M=E*D*E^(-1);

u=M*U;
%u=u/((x^2+y^2)*(x^2+y^2+z^2))
simplify(u);
expand(u);
% k=expand((x^2 - y^2)*(x^2 + y^2 + z^2))

N=[x;y;z]/(x^2+y^2+z^2);
null(N');

Rx=[1 0 0;0 cos(theta1) -sin(theta1);0 sin(theta1) cos(theta1)];

Ry=[cos(theta2) 0 sin(theta2);0 1 0;-sin(theta2) 0 cos(theta2)];

Rx*Ry*[x;y;z]
E2=Rx*Ry*[x y x*z;y -x y*z;z 0 -(x^2+y^2)]
detE2
detE2000=simplify(det(E2))
detE20000=expand(detE2)

M=E*D*E^(-1)
M2=E2*D*E2^(-1)

A=[x z x*y;y 0 -x^2-z^2;z -x z*y]
simplify(det(A))








R_x = [ 1, 0, 0; 0, cos(theta1), sin(theta1); 0, -sin(theta1), cos(theta1)];
R_y = [cos(theta2), 0, -sin(theta2); 0, 1, 0; sin(theta2), 0, cos(theta2)];
R_z = [cos(theta3), sin(theta3), 0; -sin(theta3), cos(theta3), 0; 0, 0, 1];

A=R_z*e2
simplify(A)
c=((x^2 + y^2)/(x^2 + y^2 + z^2))^(1/2)
b=(x^2 + y^2 + z^2)^(1/2)
x/(c*b)