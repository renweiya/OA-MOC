clear;
clc
disp('hello')
%%
% fn_handle = @(x) limitcycle_DS(x); %defining the function handle
options.model=3;
fn_handle = @(x) globally_stable_DS_3D(x); %defining the function handle
% x0 = [-15*ones(1,3);linspace(-1,1,3);linspace(-0,0,3)]; %set of initial points
x0 = [-15*ones(1,2);linspace(-10,0,2);linspace(-0,0,2)]; %set of initial points
x0 = [-8*ones(1,1);linspace(-0,0,1);linspace(-0,0,1)]; %set of initial points
obs{1}.a  = [3;3;3];
obs{1}.p  = [1;1;1];
obs{1}.x0 = [0;0;0];
obs{1}.sf = [1;1;1];
obs{1}.th_r = [0 0 0]*pi/180;
obs{1}.partition = [-pi pi];

%%
opt_sim.obstacle = obs;
fig(3) = figure('name','First demo: Multiple obstacle avoidance','position',[380 50 560 420]);
opt_sim.figure = fig(3);
Simulation_hovering(x0,[],fn_handle,opt_sim,options);