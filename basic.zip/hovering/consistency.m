clear
clc
%rotate three times to ensure orthogonal matrix
syms x n

% x=0.99
% n=6
A=(1-x)*(1+x)^n
A=expand(A)

expand((1-x)*(1+x)^2)

hold on
a=[];
n=2;
j=1;
for x=0:0.001:1
    a(j)=(1-x)*(1+x)^n;
    j=j+1;
end
x=[0:0.001:1]
hold off