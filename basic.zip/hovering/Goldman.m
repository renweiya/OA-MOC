clear
clc
%rotate a vector around any axis(vector)

syms x y z axis angle

E=[x/sqrt(x^2+y^2) y/sqrt(x^2+y^2) 0;y/sqrt(x^2+y^2) -x/sqrt(x^2+y^2) 0;0 0 1];
x=5
y=-1
z=1
axis=[y -x 0];
axis=axis./norm(axis)

v1=([x,y,0]./(sqrt(x^2+y^2))).'
v2=([x,y,z]./(sqrt(x^2+y^2+z^2))).'

% v1=[x,y,0].'
% v2=[x,y,z].'

angle=-(z/sqrt(z^2))*acos(v1.'*v2/(sqrt(sum(v1.^2))*sqrt(sum(v2.^2))))

s = sin(angle);
c=  cos(angle);

M=[axis(1)^2*(1-c)+c,                 axis(1)*axis(2)*(1-c)+axis(3)*s, axis(1)*axis(3)*(1-c)-axis(2)*s;
   axis(1)*axis(2)*(1-c)-axis(3)*s ,  axis(2)^2*(1-c)+c,               axis(2)*axis(3)*(1-c)+axis(1)*s;
   axis(1)*axis(3)*(1-c)+axis(2)*s ,  axis(2)*axis(3)*(1-c)-axis(1)*s, axis(3)^2*(1-c)+c;];

u=M*v1
u_s=simplify(M*E)

A=(M^(-1)-M')