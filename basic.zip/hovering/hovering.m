clc
clear

fn_handle = @(x) globally_stable_DS(x); %defining the function handle

x0 = [-27*ones(1,10);linspace(-10,10,10)]; %set of initial points
x0 = [-8*ones(1,1);linspace(-0,0,1)]; %set of initial points

% x0 = [temp_start;temp_end]; %set of initial points


% (1-((-26.448285+9)^2+1)/3.6^2)*pi/2

% x0 = [-26.448285;0]; %set of initial points
% % A set of parameters that should be defined for the simulation
options.model=3;
clear obs;
obs{1}.a  = [3;3];
obs{1}.p  = [1;1];
obs{1}.x0 = [0;0];
obs{1}.sf = [1.2;1.2];
obs{1}.th_r = [0 0]*pi/180;
obs{1}.partition = [-pi pi];

% obs{2}.a  = [3;3];
% obs{2}.p  = [1;1];
% obs{2}.x0 = [-9;-5];
% obs{2}.sf = [1.2;1.2];
% obs{2}.th_r = [0 0]*pi/180;
% obs{2}.partition = [-pi pi];
% 
% obs{3}.a  = [3;3];
% obs{3}.p  = [2;2];
% obs{3}.x0 = [-20;0];
% obs{3}.sf = [1.2;1.2];
% obs{3}.th_r = [0 0]*pi/180;
% obs{3}.partition = [-pi pi];

% obs{4}.a  = [3;3];
% obs{4}.p  = [2;2];
% obs{4}.x0 = [-20;0];
% obs{4}.sf = [1.2;1.2];
% obs{4}.th_r = [0 0]*pi/180;
% obs{4}.partition = [-pi pi];
%%
opt_sim.obstacle = obs;
fig(3) = figure('name','First demo: Multiple obstacle avoidance','position',[380 50 560 420]);
opt_sim.figure = fig(3);
Simulation_hovering(x0,[],fn_handle,opt_sim,options);
% Simulation(x0,[],fn_handle,opt_sim,options);
