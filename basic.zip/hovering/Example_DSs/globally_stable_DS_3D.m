function xd = globally_stable_DS_3D(x)
xd = - x(1,:);
% xd(2,:) = - x(1,:) .* cos(x(1,:)) - x(2,:);%original
xd(2,:) = - x(2,:);
xd(3,:) = - x(3,:);