clear
clc
%rotate three times to ensure orthogonal matrix
syms x y z nata1 nata2 nata3 E E1 u1 u2 u3 xyz r1 r2 a b c d e f theta1 theta2
% x=1;%-1
% y=2;%-2
% z=3;%-3

E=[x/sqrt(x^2+y^2) y/sqrt(x^2+y^2) 0;y/sqrt(x^2+y^2) -x/sqrt(x^2+y^2) 0;0 0 1];
% E_000=[x y x*z;y -x y*z;z 0 -(y^2+x^2)]
% simplify(det(E_000))
%%
e1=[x/sqrt(x^2+y^2) y/sqrt(x^2+y^2) 0].';
e2=[x/sqrt(x^2+y^2+z^2) y/sqrt(x^2+y^2+z^2) z/sqrt(x^2+y^2+z^2)].';
% e1=[x,y,0].';
% e2=[x,y,z].';

%%
e1_x=[1 0 0].';
theta3=sign(y)*acos(e1.'*e1_x/(sqrt(sum(e1.^2))*sqrt(sum(e1_x.^2))));%y:��ʱ��,˳ʱ��
% theta3=acos(e1.'*e1_x/(sqrt(sum(e1.^2))*sqrt(sum(e1_x.^2))));%y:��ʱ��,˳ʱ�룬y>0
R_z = [cos(theta3), sin(theta3), 0; -sin(theta3), cos(theta3), 0; 0, 0, 1];
e_temp1=R_z*e1;
%%
e11=[1 0 0].';
e22=[sqrt((e2(1))^2+(e2(2))^2) 0 e2(3)].';
theta2=sign(z)*acos(e11.'*e22/(sqrt(sum(e11.^2))*sqrt(sum(e22.^2))));
% theta2=acos(e11.'*e22/(sqrt(sum(e11.^2))*sqrt(sum(e22.^2))));%z>0

R_y = [cos(theta2), 0, -sin(theta2); 0, 1, 0; sin(theta2), 0, cos(theta2)];
e_temp2=R_y*e_temp1;
e_temp2=e_temp2*norm(e2)/norm(e1);%manitude

%%
theta1=-theta3;
R_z2 = [cos(theta1), sin(theta1), 0; -sin(theta1), cos(theta1), 0; 0, 0, 1];
e_temp3=R_z2*e_temp2;
%%
e55=e2;

theta0=acos(e55.'*e_temp3/(sqrt(sum(e55.^2))*sqrt(sum(e_temp3.^2))));
% acos(((y*((cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*((y*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) - (x*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2) + (cos((z*acos((x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2))^(1/2)/(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))/abs(z))*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*((x*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) + (y*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2)))/(x^2 + y^2 + z^2)^(1/2) - (x*((sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*((y*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) - (x*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2) - (cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*cos((z*acos((x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2))^(1/2)/(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))/abs(z))*((x*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) + (y*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2)))/(x^2 + y^2 + z^2)^(1/2) + (z*sin((z*acos((x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2))^(1/2)/(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))/abs(z))*((x*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) + (y*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/((abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2)*(x^2 + y^2 + z^2)^(1/2)))/((((cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*((y*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) - (x*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2) + (cos((z*acos((x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2))^(1/2)/(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))/abs(z))*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*((x*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) + (y*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2))^2 + ((sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*((y*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) - (x*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2) - (cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y))*cos((z*acos((x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2))^(1/2)/(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))/abs(z))*((x*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) + (y*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2))^(1/2))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2))^(1/2))^2 + (sin((z*acos((x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2))^(1/2)/(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))/abs(z))^2*((x*cos((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2) + (y*sin((y*acos(x/((x^2 + y^2)^(1/2)*(x^2/(x^2 + y^2) + y^2/(x^2 + y^2))^(1/2))))/abs(y)))/(x^2 + y^2)^(1/2))^2*(abs(x)^2/abs(x^2 + y^2 + z^2) + abs(y)^2/abs(x^2 + y^2 + z^2) + abs(z)^2/abs(x^2 + y^2 + z^2)))/(abs(x)^2/abs(x^2 + y^2) + abs(y)^2/abs(x^2 + y^2)))^(1/2)*(x^2/(x^2 + y^2 + z^2) + y^2/(x^2 + y^2 + z^2) + z^2/(x^2 + y^2 + z^2))^(1/2)))
 
M=R_z2*R_y*R_z;
E_new=M*E;




% R_z
% R_y
% R_z2
% R_y=simplify(R_y)
% R_z=simplify(R_z)
% R_z2=simplify(R_z2)
%% simplify
R_z000=[  x/(x^2 + y^2)^(1/2),             y/(x^2 + y^2)^(1/2),  0;
       -y/(x^2 + y^2)^(1/2),         x/(x^2 + y^2)^(1/2),        0;
                       0,                  0,                    1];
   
                                    
R_y000=[((x^2 + y^2)/(x^2 + y^2 + z^2))^(1/2)  , 0, -z/(x^2 + y^2 + z^2)^(1/2);
                                           0  , 1,                                  0;
       z/(x^2 + y^2 + z^2)^(1/2), 0,  ((x^2 + y^2)/(x^2 + y^2 + z^2))^(1/2) ];
   

R_z222=[ x/(x^2 + y^2)^(1/2),        -y/(x^2 + y^2)^(1/2),   0;
 y/(x^2 + y^2)^(1/2),     x/(x^2 + y^2)^(1/2),               0;
           0,                         0,                     1];
         
R_simplify=R_z222*R_y000*R_z000;
E_simplify=R_simplify*E
simplify(E_simplify)

% E_simplify^(-1)-E_simplify.'
% norm(R_y-R_y000)
% norm(R_z-R_z000)
% norm(R_z2-R_z222)
% a=E_new(:,1)
% b=e2(:,1)